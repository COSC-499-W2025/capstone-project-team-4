export const team = ['a','b'];
